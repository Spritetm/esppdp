/*	sgtty.h	4.2	85/01/03	*/

#ifndef	_IOCTL_
#include <sys/ioctl.h>
#endif
